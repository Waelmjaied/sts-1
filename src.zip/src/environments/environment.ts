export const environment = {
  production: false,
  apiUrl: 'http://127.0.0.1:12000/'
};
